# Demo项目说明

### 1. 运行环境
* 字符集  UTF-8
* Java 8 以上
* Maven 3 以上

  

